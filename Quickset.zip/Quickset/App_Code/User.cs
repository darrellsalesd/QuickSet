﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

/// <summary>
/// Summary description for User
/// </summary>
public class User
{
    public User()
    {
        //
        // TODO: Add constructor logic here
        //
    }
  public String GetUsername(int UserID)
  {

    DBManager myDBManager = new DBManager();
    string myQuery = "spGetSpecificUser";
    SqlParameter[] myParameters = new SqlParameter[1];
    myParameters[0] = new SqlParameter("userID", UserID);


    DataSet myDataSet = myDBManager.createDataSet(myQuery, myParameters);

    string finalResult = "";

    for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
    {


      finalResult += myDataSet.Tables[0].Rows[i]["username"] + "<br>";
    }

    return finalResult;

  }

  public int insertSet(int userID, string title)
  {
    DBManager myDBManager = new DBManager();
    string myQuery = "spInsertSet";

    SqlParameter[] myParameters = new SqlParameter[2];
    myParameters[0] = new SqlParameter("userID", userID);
    myParameters[1] = new SqlParameter("title", title);


    int rows = myDBManager.executeNonQuery(myQuery, myParameters);
    return rows;
  }
  public int insertSong(string title, string artist, int BPM, int duration)
  {
    DBManager myDBManager = new DBManager();
    string myQuery = "spInsertSet";

    SqlParameter[] myParameters = new SqlParameter[4];
    myParameters[0] = new SqlParameter("title", title);
    myParameters[1] = new SqlParameter("artist", artist);
    myParameters[2] = new SqlParameter("BPM", BPM);
    myParameters[3] = new SqlParameter("duration", duration);


    int rows = myDBManager.executeNonQuery(myQuery, myParameters);
    return rows;
  }

  public String GetSets(int UserID)
  {

    DBManager myDBManager = new DBManager();
    string myQuery = "spGetSpecificUser";
    SqlParameter[] myParameters = new SqlParameter[1];
    myParameters[0] = new SqlParameter("userID", UserID);


    DataSet myDataSet = myDBManager.createDataSet(myQuery, myParameters);

    string finalResult = "";

    for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
    {


      finalResult += myDataSet.Tables[0].Rows[i]["title"] + "<br>";
    }

    return finalResult;

  }

  public int GetUserID(string email, string password)
    {

        DBManager myDBManager = new DBManager();

        string myQuery = "spSelectEmailPass";
        Byte[] encryptedPWD = encrypt(password);
        SqlParameter[] myParameters = new SqlParameter[2];
        myParameters[0] = new SqlParameter("email", email);
        myParameters[1] = new SqlParameter("password", encryptedPWD);


        DataSet myDataSet = myDBManager.createDataSet(myQuery, myParameters);


        string finalResult = "";

        for (int i = 0; i < myDataSet.Tables[0].Rows.Count; i++)
        {
            finalResult += myDataSet.Tables[0].Rows[i]["userID"];
        }



        int userID = Int32.Parse(finalResult);

        return userID;
    }

    public int delAllSets()
    {
      DBManager myDBManager = new DBManager();
      string myQuery = "spDellAllSets";

    SqlParameter[] myParameters = new SqlParameter[0];

      int rows = myDBManager.executeNonQuery(myQuery, myParameters);
      return rows;
    }


  public int updateUser(int UserID, string firstName, string lastName)
    {
        DBManager myDBManager = new DBManager();
        string myQuery = "spUpdateUser";

        SqlParameter[] myParameters = new SqlParameter[3];
        myParameters[0] = new SqlParameter("firstName", firstName);
        myParameters[1] = new SqlParameter("lastName", lastName);
        myParameters[2] = new SqlParameter("userID", UserID);

        int rows = myDBManager.executeNonQuery(myQuery, myParameters);
        return rows;
    }

    public int insertUser(string email, string username, string password)
    {
        DBManager myDBManager = new DBManager();
        string myQuery = "spInsertUser";

        Byte[] encryptedPWD = encrypt(password);
        SqlParameter[] myParameters = new SqlParameter[3];
        myParameters[0] = new SqlParameter("email", email);
        myParameters[1] = new SqlParameter("username", username);
        myParameters[2] = new SqlParameter("password", encryptedPWD);

        int rows = myDBManager.executeNonQuery(myQuery, myParameters);
        return rows;
    }

    public Boolean isUser(string email, string password)
    {
        DBManager myDBManager = new DBManager();
        Byte[] encryptedPWD = encrypt(password);

        string myQuery = "spSelectEmailPass";
        SqlParameter[] myParameters = new SqlParameter[2];
        myParameters[0] = new SqlParameter("email", email);
        myParameters[1] = new SqlParameter("password", encryptedPWD);


        DataSet myDataSet = myDBManager.createDataSet(myQuery, myParameters);



        if (myDataSet.Tables[0].Rows.Count != 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    private Byte[] encrypt(string unencryptedString)
    {
        // encrypt password before inserted..
        Byte[] hashedDataBytes = null;
        UTF8Encoding encoder = new UTF8Encoding();

        MD5CryptoServiceProvider md5Hasher = new MD5CryptoServiceProvider();

        hashedDataBytes = md5Hasher.ComputeHash(encoder.GetBytes(unencryptedString));

        return hashedDataBytes;
    }

    public int DeleteUser(int UserID)
    {

        DBManager myDBManager = new DBManager();

        string myQuery = "spDeleteUser";
        SqlParameter[] myParameters = new SqlParameter[1];
        myParameters[0] = new SqlParameter("userID", UserID);

        int rows = myDBManager.executeNonQuery(myQuery, myParameters);

        return rows;
    }


}