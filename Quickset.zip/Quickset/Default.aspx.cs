﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {
    SqlConnection con = new SqlConnection("Data Source=(local);Initial Catalog=QuickSet;User ID=quickset;Password=pass");
    SqlDataAdapter da = new SqlDataAdapter("select * from Sets", con);
    DataSet ds = new DataSet();
    da.Fill(ds, "FillComent");
    setListView.DataSource = ds.Tables["FillComent "];
    setListView.DataBind();

    SqlConnection cond = new SqlConnection("Data Source=(local);Initial Catalog=QuickSet;User ID=quickset;Password=pass");
    SqlDataAdapter dad = new SqlDataAdapter("select * from Songs", cond);
    DataSet dsd = new DataSet();
    dad.Fill(dsd, "FillComent");
    songList.DataSource = dsd.Tables["FillComent "];
    songList.DataBind();
  }


  protected void btnNewSet_Click(object sender, EventArgs e)
  {
    if (Session["UserID"] != null)
    {
      int userID = Int32.Parse(Session["UserID"].ToString());
      User myUser = new User();
      String newSetTitle = setTitleTextBox.Text;
      myUser.insertSet(userID,newSetTitle);
    }
  }

  protected void btnDelAll_Click(object sender, EventArgs e)
  {
    if (Session["UserID"] != null)
    {
      User myUser = new User();
      myUser.delAllSets();
    }
  }

  protected void btnLoadSet_Click(object sender, EventArgs e)
  {
    if (Session["UserID"] != null)
    {
      if(setTitleTextBox.Text != null)
      {
        currentSet.Text = setTitleTextBox.Text;
      }
    }
  }

  protected void Unnamed8_Click(object sender, EventArgs e)
  {
    if (Session["UserID"] != null)
    {
      User myUser = new User();
      myUser.insertSong(titleTextBox.Text, songArtist.Text, Int32.Parse(songBPM.Text), Int32.Parse(songDuration.Text));
    }

  }

  
}