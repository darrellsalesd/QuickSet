﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
  protected void Page_Load(object sender, EventArgs e)
  {
    panelLogOut.Visible = false;

    if (Session["UserID"] != null)
    {
      User myUser = new User();
      int userID = Int32.Parse(Session["UserID"].ToString());
      panelLogOut.Visible = true;
      panelLogin.Visible = false;
    }
  }

    protected void linkBtnLogin_Click(object sender, EventArgs e)
    {
      Response.Redirect("Login.aspx");
    }

    protected void linkBtnLogOut_Click(object sender, EventArgs e)
    {
      if (Session["UserID"] != null)
      {
        Session["UserID"] = null;
      }
      panelLogOut.Visible = false;
      panelLogin.Visible = true;
    }
}
