﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Registration : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {

  }

  protected void btnLogin_Click(object sender, EventArgs e)
  {
    Server.Transfer("Login.aspx");
  }

  protected void btnSubmit_Click(object sender, EventArgs e)
  {
    string email = emailTextBox.Text;
    string username = usernameTextBox.Text;
    string password = passwordTextBox.Text;
    string confirmPass = confirmPasswordTextBox.Text;

    User myUser = new User();

    if (password != confirmPass)
    {
      lblFeedback.Text = "Passwords do not match.";
    }
    else if (!myUser.isUser(email, password))
    {
      myUser.insertUser(email, username, password);
      lblFeedback.Text = "Successfully Registered!";
    }
    else
    {
      lblFeedback.Text = "This email is already registered.";
    }
  }
}