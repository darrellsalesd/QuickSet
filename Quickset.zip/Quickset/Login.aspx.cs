﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Login : System.Web.UI.Page
{


    protected void Page_PreInit(object sender, EventArgs e)
    {

    }


    protected void Page_Load(object sender, EventArgs e)
    {

    }
  protected void btnSubmit_Click(object sender, EventArgs e)
  {
    User myUser = new User();
    String email = emailTextBox.Text;
    String password = passwordTextBox.Text;

    if (myUser.isUser(email, password))
    {
      int userID = myUser.GetUserID(email, password);

      Session["UserID"] = userID;

      lblFeedback.Text = "Welcome " + myUser.GetUsername(userID);
      Server.Transfer("default.aspx");
    }
    else
    {
      lblFeedback.Text = "Invalid Username/Password";
    }
  }

  protected void linkBtnRegister_Click(object sender, EventArgs e)
  {
    Server.Transfer("Registration.aspx");
  }
}